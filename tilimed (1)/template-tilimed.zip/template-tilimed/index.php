<!DOCTYPE html>
<html lang="ru">
	<head>
		<meta charset="utf-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, viewport-fit=cover">
		<meta name="description" content="Описание страницы">
		<meta name="format-detection" content="telephone=no">
		<title>Главная страница</title><!-- Styles Section  -->
		<link rel="preconnect" href="https://fonts.googleapis.com">
		<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="">
		<link href="https://fonts.googleapis.com/css2?family=Ubuntu:ital,wght@0,300;0,400;0,500;0,700;1,300;1,400;1,500;1,700&amp;display=swap" rel="stylesheet">
		<link rel="stylesheet" href="<?=$get_template_directory_uri?>/template-tilimed/css/main.css?v=1711572608838">
	</head>
	<body>
		<div class="site"><!-- Header Section  -->
			<header class="header">
				<div class="container">
					<div class="header__wrapper"><a class="header__logo logo" href="/"><img class="logo__img" src="<?=$get_template_directory_uri?>/template-tilimed/logo.svg" alt="logo" width="175" height="60"></a>
						<div class="header__navbar">
							<nav class="header__menu"><a class="header__link" href="/analyzes.html">Анализы</a><a class="header__link" href="/maps.html">Карта лабораторий</a><a class="header__link" href="/faq.html">Вопрос-ответ</a><a class="header__link" href="/instructions.html">Инструкции</a><a class="header__link" href="/about.html">База знаний</a>
							</nav>
							<div class="header__actions"><a class="btn btn--blue" href="/authorization.html"><span>Войти</span>
									<svg class="btn__icon">
										<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#small-arrow-right"></use>
									</svg></a><a class="btn btn--basket" href="/basket.html">
									<svg>
										<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#basket"></use>
									</svg></a></div>
						</div>
						<button class="btn header__burger js-burger" type="button"></button>
					</div>
					<div class="mobile-menu">
						<div class="container">
							<div class="mobile-menu__picture">
								<div class="gallery__items">
									<div class="gallery__item"><img class="gallery__image" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/bg-9.jpg" alt="ALT" loading="lazy"/></div>
									<div class="gallery__item"><img class="gallery__image" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/bg-1.jpg" alt="ALT" loading="lazy"/></div>
									<div class="gallery__item"><img class="gallery__image" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/bg-10.jpg" alt="ALT" loading="lazy"/></div>
									<div class="gallery__item"><img class="gallery__image" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/bg-11.jpg" alt="ALT" loading="lazy"/></div>
								</div>
							</div>
							<div class="mobile-menu__content"><a class="mobile-menu__logo logo" href="/"><img class="logo__img" src="<?=$get_template_directory_uri?>/template-tilimed/logo.svg" alt="logo" width="175" height="60"></a>
								<div class="mobile-menu__block">
									<nav class="mobile-menu__nav"><a class="mobile-menu__link" href="/analyzes.html">Анализы</a><a class="mobile-menu__link" href="/maps.html">Карта лабораторий</a><a class="mobile-menu__link" href="/faq.html">Вопрос-ответ</a><a class="mobile-menu__link" href="/instructions.html">Инструкции</a><a class="mobile-menu__link" href="/about.html">База знаний</a><a class="mobile-menu__link mobile-menu__basket" href="/basket.html">
											<svg>
												<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#basket"></use>
											</svg></a>
									</nav><a class="btn btn--blue mobile-menu__btn" href="/authorization.html"><span>Войти</span>
										<svg class="btn__icon">
											<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#small-arrow-right"></use>
										</svg></a>
									<button class="btn btn__close js-burger-close" type="button"></button>
								</div>
							</div>
						</div>
					</div>
				</div>
			</header><!-- Main Section  -->
			<main class="main">
				<section class="hero section">
					<div class="container">
						<div class="hero__wrapper">
							<div class="row gy-2">
								<div class="col-12 col-xl-6">
									<div class="hero__block">
										<div class="hero__block-top">
											<p class="hero__subtitle">Первый Мобильный оператор лабораторий</p>
											<h1 class="hero__title">Самостоятельное тестирование на инфекции, передаваемые половым путем</h1>
											<button class="btn btn--blueLine" type="buttom">Выбрать анализы
												<svg>
													<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#arrow-line-right"></use>
												</svg>
											</button>
										</div>
										<div class="hero__block-bottom"><a class="hero__location" href="#">
												<svg>
													<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#location"></use>
												</svg>Открыть карту лабораторий</a>
											<div class="hero__contacts"> 
												<button class="btn btn--grey" type="button"><span>Связь с нами</span>
													<svg>
														<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#phone-circle"></use>
													</svg>
												</button>
												<div class="hero__socials"><a class="hero__icon" href="mailto:" target="_blank" rel="nofollow">
														<svg>
															<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#mail"></use>
														</svg></a><a class="hero__icon" href="#" target="_blank" rel="nofollow">
														<svg>
															<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#telegram"></use>
														</svg></a><a class="hero__icon" href="#" target="_blank" rel="nofollow">
														<svg>
															<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#vk"></use>
														</svg></a><a class="hero__icon" href="#" target="_blank" rel="nofollow">
														<svg>
															<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#instagram"></use>
														</svg></a>
												</div>
											</div>
										</div>
									</div>
								</div>
								<div class="col-12 col-xl-6">
									<div class="hero-stock" style="background-image: url('./images/content/hero.jpg');">
										<div class="hero-stock__block">
											<div class="hero-stock__header">
												<div class="hero-stock__title">Акция</div>
												<svg class="hero-stock__icon">
													<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#alarm"></use>
												</svg>
											</div>
											<div class="hero-stock__body">
												<h5 class="hero-stock__body-title">-10% от 3-х анализов</h5>
												<p class="hero-stock__body-subtitle">При оформлении заказа 3-х и более заказов действует скидка до <b>
														 29.02.2024</b></p>
											</div>
										</div>
									</div>
								</div>
							</div>
							<div class="row gy-2">
								<div class="col-12 col-lg-6 col-xl-4"><a class="hero-analyses" href="#">
										<div class="hero-analyses__icon">
											<svg>
												<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#arrow-up-deg"></use>
											</svg>
										</div>
										<div class="hero-analyses__count">30+</div>
										<div class="hero-analyses__title">Анализов доступны для тестирования в TILIMED с широкой георграфией по России.</div>
										<div class="hero-analyses__subtitle">У многих нет времени записаться к врачу. Кто-то стесняется. Медицина стремится в онлайн, и мы - тоже.</div></a></div>
								<div class="col-12 col-lg-6 d-none d-xl-block col-xl-4"><img class="hero-image" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/vector-1.svg" alt="vector"></div>
								<div class="col-12 col-lg-6 col-xl-4"><a class="hero-faq" href="#">
										<div class="hero-faq__icon">
											<svg>
												<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#arrow-up-deg"></use>
											</svg>
										</div>
										<div class="hero-faq__block">
											<div class="hero-faq__header">
												<div class="hero-faq__title">Отвечаем на вопросы</div>
												<div class="hero-faq__body">
													<p>
														 Почему у нас дешевле, чем в лабораториях?</p>
													<p>Нужны ли показания для выбора анализов?</p>
													<p>Можно ли проконсультироваться с врачом?</p>
												</div>
											</div>
											<div class="hero-faq__footer">
												<div class="hero-faq__desc">и другие вопросы</div>
											</div>
										</div></a></div>
							</div>
						</div>
					</div>
				</section>
				<section class="facilities section">
					<div class="container">
						<div class="facilities__wrapper">
							<div class="facilities__block">
								<div class="facilities__tags">
									<div class="facilities__tag facilities__tag--black">Достоверность</div>
									<div class="facilities__tag facilities__tag--blue">Анонимность</div>
									<div class="facilities__tag facilities__tag--pink">Удобство</div>
								</div>
								<p class="facilities__body">-	Возможность сдачи анализов <span class="primary-text font-medium">в комфортных условиях</span> дома или уборной в лаборатории<br><br>-	<span class="primary-text font-medium">Информативность</span> самодиагностики равноценна информативности забора анализов квалифицированными медицинскими работниками<br><br>-	Сотрудничество с крупными сетями лабораторий (гемотест, лабстори), расположенными по всей территории России <br><br>-	<span class="primary-tex font-mediumt">Уменьшение стоимости</span> анализов до 50% от изначального тарифа.</p>
							</div>
							<div class="facilities__sliders">
								<div class="facilities__slider"><img class="facilities__slide" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/bg-11.jpg" alt="bg-11"><img class="facilities__slide" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/bg-9.jpg" alt="bg-9"><img class="facilities__slide" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/bg-1.jpg" alt="bg-1"><img class="facilities__slide" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/quality-7.jpg" alt="quality-7">
								</div>
								<div class="facilities__slider"><img class="facilities__slide" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/bg-2.jpg" alt="bg-2"><img class="facilities__slide" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/bg-12.jpg" alt="bg-12"><img class="facilities__slide" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/bg-13.jpg" alt="bg-13"><img class="facilities__slide" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/bg-7.jpg" alt="bg-7">
								</div>
							</div>
						</div>
					</div>
				</section>
				<section class="about section">
					<div class="container">
						<div class="about__wrapper">
							<h2 class="about__title">Как мы работаем</h2>
							<div class="row gy-2">
								<div class="col-12 col-md-6"><a class="about-block about-block--first" href="/login.html">
										<div class="about-block__icon">
											<svg>
												<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#arrow-up-deg"></use>
											</svg>
										</div>
										<div class="about-block__count">01.</div>
										<div class="about-block__body">
											<ul class="about-block__lists">
												<li class="about-block__list">Регистрируемся на <b>Tilimed.com</b></li>
												<li class="about-block__list">Получаем инструкцию</li>
												<li class="about-block__list">Выбираем на сайте необходимые для <br/>тестирования анализы</li>
												<li class="about-block__list">Оплачиваем</li>
											</ul>
										</div><img class="about-block__image" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/icon-1.svg" alt="icon-1" loading="lazy"></a>
								</div>
								<div class="col-12 col-md-6"><a class="about-block about-block--second" href="/instructions.html">
										<div class="about-block__icon">
											<svg>
												<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#arrow-up-deg"></use>
											</svg>
										</div>
										<div class="about-block__count">02.</div>
										<div class="about-block__body">
											<ul class="about-block__lists">
												<li class="about-block__list">Посещаем лабораторию-партнера</li>
												<li class="about-block__list">Говорим кодовое словосочетание “Tilimed Self-test”</li>
												<li class="about-block__list">Берем виалу - специальный контейнер <br/>для набора материала</li>
												<li class="about-block__list">Самостоятельно берем материал, <br/><b>следуя инструкциям</b></li>
											</ul>
										</div><img class="about-block__image" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/icon-2.svg" alt="icon-2" loading="lazy"></a>
								</div>
								<div class="col-12 col-md-6">
									<div class="about-block">
										<div class="about-block__count">03.</div>
										<div class="about-block__body">
											<ul class="about-block__lists">
												<li class="about-block__list">Возвращаем виалу в лабораторию, <br/>показываем талон регистрации и оплаты</li>
												<li class="about-block__list">Ожидаем результат</li>
											</ul>
										</div><img class="about-block__image" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/icon-3.svg" alt="icon-3" loading="lazy">
									</div>
								</div>
								<div class="col-12 col-md-6">
									<div class="about-block">
										<div class="about-block__count">04.</div>
										<div class="about-block__body">
											<ul class="about-block__lists">
												<li class="about-block__list">Получаем результат сразу по готовности <br/>в кратчайшие сроки:</li>
											</ul>
											<ul class="about-block__desc">
												<li>в электронном виде</li>
												<li>с клиническими рекомендациями <br/>специалистов</li>
											</ul>
										</div><img class="about-block__image" src="<?=$get_template_directory_uri?>/template-tilimed/images/content/icon-4.svg" alt="icon-4" loading="lazy">
									</div>
								</div>
							</div>
						</div>
					</div>
				</section>
				<section class="thesis section">
					<div class="container">
						<div class="thesis-block">Всем необходимо периодически тестироваться, вести личный мониторинг инфекций передающихся половым путем методом ПЦР</div>
					</div>
				</section>
				<section class="map section">
					<div class="container">
						<div class="map-frame"><img src="<?=$get_template_directory_uri?>/template-tilimed/images/content/map-test.jpg" alt=""></div>
					</div>
				</section>
			</main><!-- Footer Section  -->
			<footer class="footer">
				<div class="container">
					<div class="footer__top">
						<nav class="footer__nav">
							<div class="footer__nav-item">
								<h3 class="footer__nav-title">Главная</h3>
								<div class="footer__nav-lists"><a class="js-to-anchor footer__nav-link" href="#facilities.html">Удобства</a><a class="js-to-anchor footer__nav-link" href="#jobs.html">Как мы работаем</a><a class="js-to-anchor footer__nav-link" href="#doctors.html">Наши врачи</a><a class="js-to-anchor footer__nav-link" href="#map.html">Карта лабораторий</a>
								</div>
							</div>
							<div class="footer__nav-item">
								<h3 class="footer__nav-title">Анализы</h3>
								<div class="footer__nav-lists"><a class="footer__nav-link" href="#analyzes.html">Качественные
										<svg>
											<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#arrow-right"></use>
										</svg></a><a class="footer__nav-link" href="#analyzes.html">Количественные
										<svg>
											<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#arrow-right"></use>
										</svg></a>
								</div>
							</div>
							<div class="footer__nav-item">
								<h3 class="footer__nav-title">Дополнительно</h3>
								<div class="footer__nav-lists"><a class="footer__nav-link" href="/instructions.html">Инструкции</a><a class="footer__nav-link" href="/about.html">База знаний</a><a class="footer__nav-link" href="/faq.html">Вопрос-ответ</a>
								</div>
							</div>
							<div class="footer__nav-urls">
								<div class="footer__nav-url"><a class="footer__nav-link footer__nav-underline" href="policy.html">Политика конфиденциальности</a></div>
								<div class="footer__nav-url"><a class="footer__nav-link footer__nav-underline" href="cookie.html">Политика использования cookie</a></div>
								<div class="footer__nav-url"><a class="footer__nav-link footer__nav-underline" href="offers.html">Договор оферты</a></div>
								<div class="footer__nav-url"><a class="footer__nav-link footer__nav-underline" href="licenses.html">Лицензии</a></div>
								<div class="footer__nav-url"><a class="footer__nav-link footer__nav-underline" href="rules.html">Правила оплаты</a></div>
								<div class="footer__nav-url"><a class="footer__nav-link footer__nav-underline" href="return.html">Возврат</a></div>
							</div>
						</nav>
						<div class="footer-contact">
							<div class="footer-contact__mobile"><a class="btn btn--darkBLue" href="">Связь с нами
									<svg>
										<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#phone-circle"></use>
									</svg></a>
								<div class="footer-contact__lists"><a class="footer-contact__icon" href="mailto:">
										<svg>
											<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#mail"></use>
										</svg></a><a class="footer-contact__icon" href="#">
										<svg>
											<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#telegram"></use>
										</svg></a><a class="footer-contact__icon" href="#">
										<svg>
											<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#vk"></use>
										</svg></a><a class="footer-contact__icon" href="#">
										<svg>
											<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#instagram"></use>
										</svg></a>
								</div>
							</div>
							<div class="footer-contact__desktop">
								<div class="footer-contact__social">
									<div class="footer-contact__title">Социальные сети</div>
									<div class="footer-contact__lists"><a class="footer-contact__icon" href="#">
											<svg>
												<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#telegram"></use>
											</svg></a><a class="footer-contact__icon" href="#">
											<svg>
												<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#vk"></use>
											</svg></a><a class="footer-contact__icon" href="#">
											<svg>
												<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#instagram"></use>
											</svg></a>
									</div>
								</div>
								<div class="footer-contact__callback">
									<div class="footer-contact__title">Контакты</div>
									<div class="footer-contact__row"><a class="btn btn--darkBLue" href="">Связь с нами
											<svg>
												<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#phone-circle"></use>
											</svg></a><a class="footer-contact__icon" href="mailto:">
											<svg>
												<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#mail"></use>
											</svg></a></div>
								</div>
							</div>
						</div>
					</div>
					<div class="footer__bottom">
						<button class="btn btn--white" type="button">Войти
							<svg class="btn__icon">
								<use xlink:href="<?=$get_template_directory_uri?>/template-tilimed/images/sprites.svg#small-arrow-right"></use>
							</svg>
						</button>
						<div class="footer__info">
							<h5>Правообладатель - Дудова Кристина Андреевна</h5>
							<p>Перепечатка и воспроизведение материалов, а также любых фрагментов из них, в том числе в порядке подпункта 3 пункта 1 статьи 1274 ГК РФ, возможны лишь с письменного разрешения правообладателя.</p>
						</div>
					</div>
				</div>
			</footer>
		</div><!-- Scripts Section  -->
		<script src="https://code.jquery.com/jquery-3.7.1.min.js"> </script>
		<script src="<?=$get_template_directory_uri?>/template-tilimed/js/vendor.js?v=1711572608838"></script>
		<script src="<?=$get_template_directory_uri?>/template-tilimed/js/main.js?v=1711572608838"></script>
	</body>
</html>